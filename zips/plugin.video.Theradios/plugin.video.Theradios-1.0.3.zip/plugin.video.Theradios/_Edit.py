import xbmcaddon

MainBase = 'https://goo.gl/ePk5Lv'
addon = xbmcaddon.Addon('plugin.video.Theradios')
